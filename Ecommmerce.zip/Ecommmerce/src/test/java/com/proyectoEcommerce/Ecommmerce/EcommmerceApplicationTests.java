package com.proyectoEcommerce.Ecommmerce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcommmerceApplicationTests {

	@Test
	void contextLoads() {
	}

}
